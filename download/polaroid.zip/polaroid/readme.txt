
Polaroid PSD
http://kennedysgarage.com/polaroid-psd

----------------------------

The personal use of this is free. If you want to use this for commercial use, including non-profit, you must purchase a license from the Kennedy's Garage website. Unauthorized copying, sale or distribution is strictly prohibited. Please give credit where credit is do.

----------------------------

FAQs

WHAT IS PERSONAL USE ?
Anything that is NON-PROFIT and NON-BUSINESS RELATED.
Examples Include: your personal website, blog, your school work / course work, your own birthday invitations (made and printed by you) and family scrapbooks.

WHAT IS COMMERCIAL USE ?
Anything that is NON-PERSONAL, ANYTHING RELATED TO BUSINESS or ANYTHING THAT IS SOLD, including non-profit.
Examples Include: business websites, portfolio websites, school websites, church websites, logos, business cards, letterheads, brochures, leaflets, posters, merchandise, t-shirts, books, magazines, retail packaging and advertisements.

If you are unsure about the use and license requirements, please email: kennedysgarage@gmail.com

----------------------------
Kennedy's Garage
http://kennedysgarage.com